//: Playground - noun: a place where people can play

import Cocoa

let numberofstoplights: Int = 4
var population: Int
population = 5422
let townName: String = "Knowhere"
var Unemployment: Int
Unemployment = 6
let TownDescription =
"\(townName) has a population of \(population) and \(numberofstoplights) stoplights besides their \(Unemployment) percent rate of unemployment."
print (TownDescription)


